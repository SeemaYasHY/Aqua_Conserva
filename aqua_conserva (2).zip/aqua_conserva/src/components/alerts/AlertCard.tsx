import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Droplets, Gauge, Bell, Clock, X } from "lucide-react";

interface AlertCardProps {
  id: string;
  type: "leak" | "low_level" | "pump_failure" | "high_consumption";
  title: string;
  description: string;
  location: string;
  severity: "critical" | "warning" | "info";
  timestamp: string;
  acknowledged?: boolean;
  onAcknowledge?: (id: string) => void;
  onDismiss?: (id: string) => void;
}

const AlertCard = ({
  id,
  type,
  title,
  description,
  location,
  severity,
  timestamp,
  acknowledged = false,
  onAcknowledge,
  onDismiss,
}: AlertCardProps) => {
  const getIcon = () => {
    switch (type) {
      case "leak":
        return Droplets;
      case "low_level":
        return AlertTriangle;
      case "pump_failure":
        return Gauge;
      default:
        return Bell;
    }
  };

  const getSeverityStyles = () => {
    switch (severity) {
      case "critical":
        return {
          border: "border-l-destructive",
          bg: "bg-destructive/5",
          iconBg: "bg-destructive/10",
          iconColor: "text-destructive",
          badge: "bg-destructive text-destructive-foreground",
        };
      case "warning":
        return {
          border: "border-l-chart-warning",
          bg: "bg-chart-warning/5",
          iconBg: "bg-chart-warning/10",
          iconColor: "text-chart-warning",
          badge: "bg-chart-warning text-primary-foreground",
        };
      default:
        return {
          border: "border-l-accent",
          bg: "bg-accent/5",
          iconBg: "bg-accent/10",
          iconColor: "text-accent",
          badge: "bg-accent text-accent-foreground",
        };
    }
  };

  const Icon = getIcon();
  const styles = getSeverityStyles();

  return (
    <Card
      className={`border-l-4 ${styles.border} ${styles.bg} ${
        acknowledged ? "opacity-60" : ""
      } transition-all hover:shadow-card`}
    >
      <CardContent className="p-4 md:p-5">
        <div className="flex items-start gap-4">
          {/* Icon */}
          <div className={`w-12 h-12 rounded-xl ${styles.iconBg} flex items-center justify-center shrink-0`}>
            <Icon className={`w-6 h-6 ${styles.iconColor}`} />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-4 mb-2">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-foreground">{title}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${styles.badge}`}>
                    {severity}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">{description}</p>
              </div>
              {onDismiss && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="shrink-0 h-8 w-8"
                  onClick={() => onDismiss(id)}
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>

            <div className="flex items-center flex-wrap gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <span className="font-medium">📍 {location}</span>
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {timestamp}
              </span>
            </div>

            {/* Actions */}
            {!acknowledged && onAcknowledge && (
              <div className="flex items-center gap-2 mt-4">
                <Button size="sm" variant="default" onClick={() => onAcknowledge(id)}>
                  Acknowledge
                </Button>
                <Button size="sm" variant="outline">
                  View Details
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AlertCard;
