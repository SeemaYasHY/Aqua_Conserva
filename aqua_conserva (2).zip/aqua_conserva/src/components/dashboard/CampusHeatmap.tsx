import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { MapPin } from "lucide-react";

const CampusHeatmap = () => {
  const zones = [
    { name: "Hostel Block A", usage: 85, x: 10, y: 20, size: "lg" },
    { name: "Hostel Block B", usage: 72, x: 35, y: 15, size: "lg" },
    { name: "Main Building", usage: 45, x: 55, y: 40, size: "md" },
    { name: "Laboratory", usage: 68, x: 80, y: 25, size: "md" },
    { name: "Cafeteria", usage: 55, x: 25, y: 60, size: "sm" },
    { name: "Sports Complex", usage: 38, x: 70, y: 65, size: "md" },
    { name: "Library", usage: 25, x: 50, y: 75, size: "sm" },
    { name: "Admin Block", usage: 30, x: 15, y: 80, size: "sm" },
  ];

  const getHeatColor = (usage: number) => {
    if (usage >= 70) return "bg-destructive/80";
    if (usage >= 50) return "bg-chart-warning/80";
    if (usage >= 30) return "bg-accent/80";
    return "bg-chart-tertiary/80";
  };

  const getSize = (size: string) => {
    switch (size) {
      case "lg": return "w-16 h-16";
      case "md": return "w-12 h-12";
      default: return "w-10 h-10";
    }
  };

  return (
    <Card variant="gradient">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-accent" />
          Campus Usage Heatmap
        </CardTitle>
        <CardDescription>Real-time water consumption by zone</CardDescription>
      </CardHeader>
      <CardContent>
        {/* Heatmap visualization */}
        <div className="relative h-64 bg-secondary/30 rounded-xl border border-border overflow-hidden">
          {/* Grid background */}
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--muted-foreground)) 1px, transparent 0)`,
              backgroundSize: "20px 20px",
            }}
          />

          {/* Zones */}
          {zones.map((zone, index) => (
            <div
              key={index}
              className="absolute group cursor-pointer"
              style={{ left: `${zone.x}%`, top: `${zone.y}%`, transform: "translate(-50%, -50%)" }}
            >
              <div
                className={`${getSize(zone.size)} ${getHeatColor(zone.usage)} rounded-full flex items-center justify-center text-xs font-bold text-primary-foreground shadow-lg transition-transform group-hover:scale-125`}
              >
                {zone.usage}%
              </div>
              {/* Tooltip */}
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 bg-card rounded-lg shadow-card border border-border text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                <p className="font-semibold text-foreground">{zone.name}</p>
                <p className="text-muted-foreground">{zone.usage}% capacity</p>
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 mt-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-chart-tertiary" />
            <span className="text-muted-foreground">Low (&lt;30%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent" />
            <span className="text-muted-foreground">Normal</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-chart-warning" />
            <span className="text-muted-foreground">High</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-destructive" />
            <span className="text-muted-foreground">Critical (&gt;70%)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CampusHeatmap;
