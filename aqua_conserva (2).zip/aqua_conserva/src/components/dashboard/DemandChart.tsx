import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Area, ComposedChart } from "recharts";
import { TrendingUp } from "lucide-react";

const generateDemandData = () => {
  const hours = Array.from({ length: 24 }, (_, i) => i);
  return hours.map((hour) => {
    // Simulate realistic campus water demand pattern
    let baseActual = 1000;
    if (hour >= 6 && hour <= 9) baseActual = 2500 + Math.random() * 500; // Morning peak
    else if (hour >= 12 && hour <= 14) baseActual = 2000 + Math.random() * 400; // Lunch
    else if (hour >= 18 && hour <= 21) baseActual = 2200 + Math.random() * 450; // Evening
    else if (hour >= 0 && hour <= 5) baseActual = 400 + Math.random() * 200; // Night
    else baseActual = 1200 + Math.random() * 300;

    const predicted = baseActual * (0.95 + Math.random() * 0.1);

    return {
      hour: `${hour.toString().padStart(2, "0")}:00`,
      actual: Math.round(baseActual),
      predicted: Math.round(predicted),
    };
  });
};

const DemandChart = () => {
  const data = generateDemandData();

  return (
    <Card variant="gradient" className="col-span-full lg:col-span-2">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-accent" />
              24-Hour Water Demand Forecast
            </CardTitle>
            <CardDescription>Predicted vs Actual consumption (Liters)</CardDescription>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-chart-primary" />
              <span className="text-muted-foreground">Predicted</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-chart-secondary" />
              <span className="text-muted-foreground">Actual</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="predictedGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(185 75% 45%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(185 75% 45%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis
                dataKey="hour"
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${(value / 1000).toFixed(1)}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "var(--radius)",
                  boxShadow: "var(--shadow-card)",
                }}
                labelStyle={{ color: "hsl(var(--foreground))" }}
              />
              <Area
                type="monotone"
                dataKey="predicted"
                fill="url(#predictedGradient)"
                stroke="transparent"
              />
              <Line
                type="monotone"
                dataKey="predicted"
                stroke="hsl(185 75% 45%)"
                strokeWidth={3}
                dot={false}
                activeDot={{ r: 6, strokeWidth: 2, stroke: "hsl(var(--card))" }}
              />
              <Line
                type="monotone"
                dataKey="actual"
                stroke="hsl(215 65% 50%)"
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
                activeDot={{ r: 5, strokeWidth: 2, stroke: "hsl(var(--card))" }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default DemandChart;
