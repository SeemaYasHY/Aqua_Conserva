import { Droplets, Mail, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-16">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
                <Droplets className="w-5 h-5 text-accent-foreground" />
              </div>
              <span className="text-xl font-bold">
                Aqua <span className="text-accent">Conserva</span>
              </span>
            </Link>
            <p className="text-primary-foreground/70 max-w-md mb-6">
              AI-powered water demand forecasting for sustainable campus operations. 
              Predict, optimize, and conserve.
            </p>
            <div className="flex flex-col gap-2 text-sm text-primary-foreground/60">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <span>contact@neuralflow.io</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>Campus Innovation Hub</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-primary-foreground/70">
              <li>
                <Link to="/" className="hover:text-accent transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/dashboard" className="hover:text-accent transition-colors">Dashboard</Link>
              </li>
              <li>
                <Link to="/alerts" className="hover:text-accent transition-colors">Alerts</Link>
              </li>
              <li>
                <Link to="/admin" className="hover:text-accent transition-colors">Admin Portal</Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-primary-foreground/70">
              <li>
                <span className="hover:text-accent transition-colors cursor-pointer">Documentation</span>
              </li>
              <li>
                <span className="hover:text-accent transition-colors cursor-pointer">API Reference</span>
              </li>
              <li>
                <span className="hover:text-accent transition-colors cursor-pointer">Case Studies</span>
              </li>
              <li>
                <span className="hover:text-accent transition-colors cursor-pointer">Support</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-primary-foreground/10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-primary-foreground/50">
          <p>© 2025 Aqua Conserva. Green Internship Project - 1M1B.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-primary-foreground transition-colors cursor-pointer">Privacy Policy</span>
            <span className="hover:text-primary-foreground transition-colors cursor-pointer">Terms of Service</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
