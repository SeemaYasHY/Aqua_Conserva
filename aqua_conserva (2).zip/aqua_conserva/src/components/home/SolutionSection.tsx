import { Card, CardContent } from "@/components/ui/card";
import { Brain, Cpu, LineChart, Bell, Gauge, Smartphone } from "lucide-react";

const SolutionSection = () => {
  const features = [
    {
      icon: Brain,
      title: "AI Demand Forecasting",
      description: "LSTM neural networks analyze historical data to predict water demand with 96% accuracy.",
    },
    {
      icon: Cpu,
      title: "IoT Sensor Network",
      description: "Real-time monitoring of tank levels, flow rates, and pump status across the entire campus.",
    },
    {
      icon: LineChart,
      title: "Predictive Analytics",
      description: "24-hour demand forecasts enable proactive pump scheduling and resource allocation.",
    },
    {
      icon: Bell,
      title: "Smart Alerts",
      description: "Instant notifications for leaks, unusual consumption patterns, and maintenance needs.",
    },
    {
      icon: Gauge,
      title: "Energy Optimization",
      description: "Automated pump scheduling during off-peak hours reduces energy costs by up to 35%.",
    },
    {
      icon: Smartphone,
      title: "Mobile Dashboard",
      description: "Facility managers can monitor and control operations from anywhere, anytime.",
    },
  ];

  return (
    <section className="py-24 md:py-32 bg-secondary/30 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-1/2 left-0 w-96 h-96 -translate-y-1/2 -translate-x-1/2 rounded-full bg-accent/5 blur-3xl" />
      <div className="absolute bottom-0 right-0 w-80 h-80 translate-y-1/2 translate-x-1/4 rounded-full bg-accent/5 blur-3xl" />

      <div className="container px-4 md:px-6 relative">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
            Our Solution
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Intelligent Water Management
          </h2>
          <p className="text-lg text-muted-foreground">
            Aqua Conserva combines cutting-edge AI with IoT technology to transform 
            how campuses manage their water resources.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <Card
              key={index}
              variant="glow"
              className="group fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6 md:p-8">
                <div className="w-14 h-14 rounded-2xl bg-gradient-accent flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 shadow-glow">
                  <feature.icon className="w-7 h-7 text-accent-foreground" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SolutionSection;
