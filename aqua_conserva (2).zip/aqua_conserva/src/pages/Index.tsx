import { Helmet } from "react-helmet-async";
import Navbar from "@/components/layout/Navbar";
import HeroSection from "@/components/home/HeroSection";
import ProblemSection from "@/components/home/ProblemSection";
import SolutionSection from "@/components/home/SolutionSection";
import Footer from "@/components/home/Footer";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>Aqua Conserva | AI-Powered Campus Water Demand Forecasting</title>
        <meta
          name="description"
          content="Aqua Conserva uses advanced AI and IoT sensors to forecast campus water consumption, optimize pump scheduling, and eliminate wastage through intelligent automation."
        />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <HeroSection />
          <ProblemSection />
          <SolutionSection />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;
